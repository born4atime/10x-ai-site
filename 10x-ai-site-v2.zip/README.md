# 10x AI Website

Static website for AI courses, consulting, and blog.

## Structure
- index.html (homepage)
- blog1.html (article placeholder)
- blog2.html (article placeholder)
- terms.html (terms & privacy)

## How to Deploy
Upload to GitHub and enable GitHub Pages.
